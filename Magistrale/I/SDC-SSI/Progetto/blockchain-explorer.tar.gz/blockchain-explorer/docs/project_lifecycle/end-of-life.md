<!-- (SPDX-License-Identifier: CC-BY-4.0) -->  <!-- Ensure there is a newline before, and after, this line -->

## End of Life

 - A project that is no longer actively developed or maintained.

