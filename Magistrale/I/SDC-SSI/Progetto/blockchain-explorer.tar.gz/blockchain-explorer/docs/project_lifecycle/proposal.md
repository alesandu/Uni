<!-- (SPDX-License-Identifier: CC-BY-4.0) -->  <!-- Ensure there is a newline before, and after, this line -->

## Proposal


- Hyperledger Explorer project was proposed by Christopher Ferris (IBM), Dan Middleton (Intel) and Pardha Vishnumolakala (DTCC)

  - See more about proposal on [wiki](https://wiki.hyperledger.org/display/explorer/Hyperledger+Explorer), and [Google documents](https://docs.google.com/document/d/1Z8uR_w9E9XITEe88PzkLjzH9t5bPivUhQO8OiEP7s_U/edit)
